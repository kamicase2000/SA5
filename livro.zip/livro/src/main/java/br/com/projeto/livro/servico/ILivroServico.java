package br.com.projeto.livro.servico;

import java.util.List;
import br.com.projeto.livro.modelo.Livro;

public interface ILivroServico {

    public Livro salvarLivro(Livro livro);

    public List<Livro> buscarTodosLivros();

    public Livro buscarLivroPorCodigo(Long codigo);

    public void deletarLivroPorCodigo(Long codigo);

    public void atualizarLivro(Livro livro);

}
