package br.com.projeto.livro.implementacao;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import br.com.projeto.livro.excecao.LivroNaoEncontradoExcecao;
import br.com.projeto.livro.modelo.Livro;
import br.com.projeto.livro.repositorio.LivroRepositorio;
import br.com.projeto.livro.servico.ILivroServico;

@Service
public class LivroServicoImplementacao implements ILivroServico {

    @Autowired
    private LivroRepositorio repositorio;

    @Override
    public Livro salvarLivro(Livro livro) {
        return repositorio.save(livro);
    }

    @Override
    public List<Livro> buscarTodosLivros() {
        return repositorio.findAll();
    }

    @Override
    public Livro buscarLivroPorCodigo(Long codigo) {
        Optional<Livro> opcional = repositorio.findById(codigo);
        if (opcional.isPresent()) {
            return opcional.get();
        } else {
            throw new LivroNaoEncontradoExcecao("Livro com código: " + codigo + " não encontrado.");
        }
    }

    @Override
    public void deletarLivroPorCodigo(Long codigo) {
        repositorio.delete(buscarLivroPorCodigo(codigo));
    }

    @Override
    public void atualizarLivro(Livro livro) {
        repositorio.save(livro);
    }
}
