package br.com.projeto.livro.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import br.com.projeto.livro.modelo.Livro;

public interface LivroRepositorio extends JpaRepository<Livro, Long> {

}
